let users = JSON.parse(localStorage.getItem("users")) || [];
let posts = JSON.parse(localStorage.getItem("posts")) || [];
let currentUser = localStorage.getItem("currentUser");

window.onload = () => {
  if (currentUser) showHome();
};

function register() {
  const username = document.getElementById("auth-username").value;
  const password = document.getElementById("auth-password").value;
  if (!username || !password) return alert("Please enter username and password");
  if (users.find(u => u.username === username)) return alert("Username already exists");
  users.push({ username, password });
  localStorage.setItem("users", JSON.stringify(users));
  alert("Registered successfully!");
}

function login() {
  const username = document.getElementById("auth-username").value;
  const password = document.getElementById("auth-password").value;
  const user = users.find(u => u.username === username && u.password === password);
  if (!user) return alert("Invalid credentials");
  localStorage.setItem("currentUser", username);
  currentUser = username;
  showHome();
}

function logout() {
  localStorage.removeItem("currentUser");
  location.reload();
}

function showHome() {
  document.getElementById("auth-section").style.display = "none";
  document.getElementById("home-section").style.display = "block";
  loadFeed();
}

function createPost() {
  const caption = document.getElementById("post-caption").value;
  const fileInput = document.getElementById("post-image");
  const file = fileInput.files[0];

  if (!caption && !file) return alert("Add caption or image");

  const reader = new FileReader();
  reader.onload = function () {
    const imageURL = file ? reader.result : null;
    posts.unshift({ username: currentUser, caption, imageURL, likes: 0 });
    localStorage.setItem("posts", JSON.stringify(posts));
    document.getElementById("post-caption").value = "";
    fileInput.value = "";
    loadFeed();
  };

  if (file) {
    reader.readAsDataURL(file);
  } else {
    reader.onload();
  }
}

function loadFeed() {
  const feed = document.getElementById("feed");
  feed.innerHTML = "";
  posts.forEach((post, index) => {
    const div = document.createElement("div");
    div.className = "post";
    div.innerHTML = `
      <div class="post-header">@${post.username}</div>
      ${post.imageURL ? `<img src="${post.imageURL}" class="post-img" />` : ""}
      <p>${post.caption}</p>
      <button onclick="likePost(${index})">❤️ ${post.likes}</button>
      ${post.username === currentUser ? `<button onclick="deletePost(${index})" class="delete-btn">🗑️ Delete</button>` : ""}
    `;
    feed.appendChild(div);
  });
}

function likePost(index) {
  posts[index].likes++;
  localStorage.setItem("posts", JSON.stringify(posts));
  loadFeed();
}

function deletePost(index) {
  if (confirm("Are you sure you want to delete this post?")) {
    posts.splice(index, 1); // remove from array
    localStorage.setItem("posts", JSON.stringify(posts)); // update localStorage
    loadFeed(); // refresh feed
  }
}
