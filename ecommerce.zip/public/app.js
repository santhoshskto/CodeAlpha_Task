// app.js

const products = [
  {
    id: 1,
    name: "Smartphone",
    price: 14999,
    image: "images/smartphone.jpg",
    description: "A powerful smartphone with great features."
  },
  {
    id: 2,
    name: "Headphones",
    price: 2999,
    image: "images/headphones.jpg",
    description: "Noise-cancelling over-ear headphones."
  },
  {
    id: 3,
    name: "Wrist Watch",
    price: 1999,
    image: "images/watch.jpg",
    description: "Stylish wrist watch for all occasions."
  }
];

function displayProducts(productList) {
  const productListElement = document.getElementById("product-list");
  productListElement.innerHTML = "";

  productList.forEach((product) => {
    const productEl = document.createElement("div");
    productEl.classList.add("product");
    productEl.innerHTML = `
      <img src="${product.image}" alt="${product.name}" />
      <h3>${product.name}</h3>
      <p>${product.description}</p>
      <p><strong>₹${product.price}</strong></p>
      <button onclick="addToCart(${product.id})">Add to Cart</button>
    `;
    productListElement.appendChild(productEl);
  });
}

function searchProducts() {
  const searchValue = document.getElementById("search").value.toLowerCase();
  const filtered = products.filter(product =>
    product.name.toLowerCase().includes(searchValue) ||
    product.description.toLowerCase().includes(searchValue)
  );
  displayProducts(filtered);
}

function addToCart(productId) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  const product = products.find(p => p.id === productId);
  cart.push(product);
  localStorage.setItem("cart", JSON.stringify(cart));
  alert("Added to cart!");
}

// Initialize
window.onload = () => displayProducts(products);
