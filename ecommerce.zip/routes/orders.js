const express = require("express");
const router = express.Router();

let orders = [];

router.post("/", (req, res) => {
  const { user, cart } = req.body;
  const newOrder = { id: Date.now(), user, cart };
  orders.push(newOrder);
  res.json({ message: "Order placed successfully", orderId: newOrder.id });
});

module.exports = router;
